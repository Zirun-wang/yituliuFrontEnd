import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _10826e38 = () => interopDefault(import('..\\pages\\building\\index.vue' /* webpackChunkName: "pages/building/index" */))
const _84403eac = () => interopDefault(import('..\\pages\\calculator\\index.vue' /* webpackChunkName: "pages/calculator/index" */))
const _97ab3bac = () => interopDefault(import('..\\pages\\recruit\\index.vue' /* webpackChunkName: "pages/recruit/index" */))
const _28e985ea = () => interopDefault(import('..\\pages\\stage\\index.vue' /* webpackChunkName: "pages/stage/index" */))
const _06b5544d = () => interopDefault(import('..\\pages\\video\\index.vue' /* webpackChunkName: "pages/video/index" */))
const _65273064 = () => interopDefault(import('..\\pages\\visits\\index.vue' /* webpackChunkName: "pages/visits/index" */))
const _29fbd936 = () => interopDefault(import('..\\pages\\zanchou\\index.vue' /* webpackChunkName: "pages/zanchou/index" */))
const _78777f68 = () => interopDefault(import('..\\pages\\module\\itemValue.vue' /* webpackChunkName: "pages/module/itemValue" */))
const _2a962e28 = () => interopDefault(import('..\\pages\\module\\question.vue' /* webpackChunkName: "pages/module/question" */))
const _3f607ee2 = () => interopDefault(import('..\\pages\\module\\store.vue' /* webpackChunkName: "pages/module/store" */))
const _57721c30 = () => interopDefault(import('..\\pages\\video\\item.vue' /* webpackChunkName: "pages/video/item" */))
const _61d16f6c = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/building",
    component: _10826e38,
    name: "building"
  }, {
    path: "/calculator",
    component: _84403eac,
    name: "calculator"
  }, {
    path: "/recruit",
    component: _97ab3bac,
    name: "recruit"
  }, {
    path: "/stage",
    component: _28e985ea,
    name: "stage"
  }, {
    path: "/video",
    component: _06b5544d,
    name: "video"
  }, {
    path: "/visits",
    component: _65273064,
    name: "visits"
  }, {
    path: "/zanchou",
    component: _29fbd936,
    name: "zanchou"
  }, {
    path: "/module/itemValue",
    component: _78777f68,
    name: "module-itemValue"
  }, {
    path: "/module/question",
    component: _2a962e28,
    name: "module-question"
  }, {
    path: "/module/store",
    component: _3f607ee2,
    name: "module-store"
  }, {
    path: "/video/item",
    component: _57721c30,
    name: "video-item"
  }, {
    path: "/",
    component: _61d16f6c,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
