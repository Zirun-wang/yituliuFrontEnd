import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _483fae42 = () => interopDefault(import('..\\pages\\expCal\\index.vue' /* webpackChunkName: "pages/expCal/index" */))
const _4ac0a3f8 = () => interopDefault(import('..\\pages\\gachaCal\\index.vue' /* webpackChunkName: "pages/gachaCal/index" */))
const _72fde895 = () => interopDefault(import('..\\pages\\maaRecruitData\\index.vue' /* webpackChunkName: "pages/maaRecruitData/index" */))
const _76621d6b = () => interopDefault(import('..\\pages\\packPPR\\index.vue' /* webpackChunkName: "pages/packPPR/index" */))
const _a6c202b4 = () => interopDefault(import('..\\pages\\recruit\\index.vue' /* webpackChunkName: "pages/recruit/index" */))
const _25dfb007 = () => interopDefault(import('..\\pages\\riicCal\\index.vue' /* webpackChunkName: "pages/riicCal/index" */))
const _dd2df238 = () => interopDefault(import('..\\pages\\riicSkill\\index.vue' /* webpackChunkName: "pages/riicSkill/index" */))
const _0cc5ab9e = () => interopDefault(import('..\\pages\\test\\index.vue' /* webpackChunkName: "pages/test/index" */))
const _227075b2 = () => interopDefault(import('..\\pages\\zanchou\\index.vue' /* webpackChunkName: "pages/zanchou/index" */))
const _4dc1eb2c = () => interopDefault(import('..\\pages\\module\\foot.vue' /* webpackChunkName: "pages/module/foot" */))
const _641afb60 = () => interopDefault(import('..\\pages\\module\\itemValue.vue' /* webpackChunkName: "pages/module/itemValue" */))
const _017b1830 = () => interopDefault(import('..\\pages\\module\\stage.vue' /* webpackChunkName: "pages/module/stage" */))
const _0e50b6da = () => interopDefault(import('..\\pages\\module\\store.vue' /* webpackChunkName: "pages/module/store" */))
const _620d2670 = () => interopDefault(import('..\\pages\\riicCal\\code.vue' /* webpackChunkName: "pages/riicCal/code" */))
const _75ef9770 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/expCal",
    component: _483fae42,
    name: "expCal"
  }, {
    path: "/gachaCal",
    component: _4ac0a3f8,
    name: "gachaCal"
  }, {
    path: "/maaRecruitData",
    component: _72fde895,
    name: "maaRecruitData"
  }, {
    path: "/packPPR",
    component: _76621d6b,
    name: "packPPR"
  }, {
    path: "/recruit",
    component: _a6c202b4,
    name: "recruit"
  }, {
    path: "/riicCal",
    component: _25dfb007,
    name: "riicCal"
  }, {
    path: "/riicSkill",
    component: _dd2df238,
    name: "riicSkill"
  }, {
    path: "/test",
    component: _0cc5ab9e,
    name: "test"
  }, {
    path: "/zanchou",
    component: _227075b2,
    name: "zanchou"
  }, {
    path: "/module/foot",
    component: _4dc1eb2c,
    name: "module-foot"
  }, {
    path: "/module/itemValue",
    component: _641afb60,
    name: "module-itemValue"
  }, {
    path: "/module/stage",
    component: _017b1830,
    name: "module-stage"
  }, {
    path: "/module/store",
    component: _0e50b6da,
    name: "module-store"
  }, {
    path: "/riicCal/code",
    component: _620d2670,
    name: "riicCal-code"
  }, {
    path: "/",
    component: _75ef9770,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
